package com.adapter;
import java.util.Calendar;
import java.util.GregorianCalendar;
import com.target.DateInterface;

public class DateImpl implements DateInterface{
	
	GregorianCalendar gcal = new GregorianCalendar();
	
	/*public DateImpl(GregorianCalendar gcal) {
		super();
		this.gcal = gcal;
	}*/

	public int getYear()
	{
		int y;
		y=gcal.get(Calendar.YEAR);
		return y;
	}
	/* public boolean setYear(int year)
	 {
	 }*/
	 public int getMonth()
	 {
		 int m;
			m=gcal.get(Calendar.YEAR);
			return m;
	 }
	/* public boolean setMonth(int month)
	 {
		 
	 }
	 public int getDayOfMonth()
	 {
		 
	 }
	 public boolean setDayOfMonth(int date)
	 {
		 
	 }
	 public int getHours()
	 {
		 
	 }
	 public boolean setHours(int hours) {
		 
	 }
	 public int getMinutes(){
		 {
			 
		 }
	 }
	 public boolean setMinutes(int minutes)
	 {
		 
	 }
	 public int getSeconds()
	 {
		 
	 }
	 public boolean setSeconds(int seconds)
	 {
		 
	 }*/
	 public boolean isLeapYear()
	 {
		int y=getYear(); 
		 if((y % 400 == 0) ||
			       (y % 100 != 0) &&
			       (y % 4 == 0))
			    {
			      return true;
			    }
			    else
			    {
			      return false;
			    }
	 }
}